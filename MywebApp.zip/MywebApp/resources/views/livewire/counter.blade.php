<div>
<span>{{ $count }}</span>
<button wire:click="decrement">-</button>
<button wire:click="increment">+</button>
</div>
 