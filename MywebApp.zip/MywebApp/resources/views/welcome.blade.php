<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <h2 class="text-lg font-semibold">Standard Contact</h2>
    </head>
    <body>
    <livewire:contact-form />
    <livewire:scripts />
    </body>
</html>
