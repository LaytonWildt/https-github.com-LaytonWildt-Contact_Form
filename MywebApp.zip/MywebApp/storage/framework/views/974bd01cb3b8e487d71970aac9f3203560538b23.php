<div>
<span><?php echo e($count); ?></span>
<button wire:click="decrement">-</button>
<button wire:click="increment">+</button>
</div>
<?php /**PATH C:\xampp\htdocs\MywebApp\resources\views/livewire/counter.blade.php ENDPATH**/ ?>