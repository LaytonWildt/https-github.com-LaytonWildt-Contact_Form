<?php return array (
  'contact-form' => 'App\\Http\\Livewire\\ContactForm',
  'counter' => 'App\\Http\\Livewire\\Counter',
  'search-drop-down' => 'App\\Http\\Livewire\\SearchDropDown',
);